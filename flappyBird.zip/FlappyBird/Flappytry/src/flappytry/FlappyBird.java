package flappytry;

import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;

import javax.swing.JFrame;
import javax.swing.Timer;

public class FlappyBird implements ActionListener, MouseListener, KeyListener {

    public static FlappyBird flappyBird; //through this the Renderer Class is called
    // main screen size
    public final int WIDTH = 800, HEIGHT = 750;

    public Renderer renderer;

    public Rectangle bird;

    public ArrayList<Rectangle> columns;

    public int ticks, yMotion, score;

    public boolean gameOver, started;

    public Random rand;

    public BufferedImage birdImg, bgImage, pipe;
    
    
 
    public static void main(String[] args) {
        flappyBird = new FlappyBird();
    }
    
    private int runAfterInterval = 20; // 20 milli seconds

    public FlappyBird() {

        JFrame jframe = new JFrame();
        
        Timer timer = new Timer(runAfterInterval, this); // This keyword is a reference to this class, precisely it refers to the intiated object of this class
        renderer = new Renderer();
        rand = new Random();

        jframe.add(renderer);

        // set window properties
        jframe.setTitle("Flappy Bird");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setSize(WIDTH, HEIGHT);

        // Attach event listeners
        jframe.addMouseListener(this);
        jframe.addKeyListener(this);
        jframe.setResizable(false);
        jframe.setVisible(true);

        bird = new Rectangle(WIDTH / 2, HEIGHT / 2, 40, 40);
        
        
        try {
            birdImg = ImageIO.read(new File("src/Bird4.png"));
            bgImage = ImageIO.read(new File("src/bg1.jpg"));
            pipe = ImageIO.read(new File("src/p.png"));

        } catch (IOException ex) {
            System.out.println("Error reading images");
            System.out.println(ex);
        }

        
        columns = new ArrayList<Rectangle>();
        
         for (double i = 0; i < 4; i++)
            addColumn(true);
        
        
        timer.start();  
    }

    public void addColumn(boolean start) {
        int space = 300; //space btw top and bottom column
        int width = 100;
        int height = 50 + rand.nextInt(300);
        
        if(start)
        {
        columns.add(new Rectangle(WIDTH + width + columns.size() * 300, HEIGHT - height - 75, width, height));
        columns.add(new Rectangle(WIDTH + width + (columns.size() -1) * 300, 0, width, HEIGHT - height - space));
        }
        else
        {
	columns.add(new Rectangle(columns.get(columns.size() - 1).x +600, HEIGHT - height - 75, width, height));
	columns.add(new Rectangle(columns.get(columns.size() - 1).x, 0, width, HEIGHT - height - space));
	}
    }

    public void paintColumn(Graphics g, Rectangle column) {
        
        g.drawImage(pipe, column.x, column.y, column.width, column.height, null);
    }

    public void jump() { //to start the game again with a click
        if (gameOver) {
            bird = new Rectangle(WIDTH / 2 , HEIGHT / 2 , 40, 40);
            columns.clear();
            yMotion = 0;          //Restarting the game
            score = 0;
           for (double i = 0; i < 4; i++) {
              addColumn(true);
            }

            gameOver = false;
        }

        if (!started) {
            started = true;
            
        } 
        else if (!gameOver) {
            if (yMotion > 0) {
                yMotion = 0;   //makes the bird fall
            }

            yMotion -= 10;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int speed = 10;
        ticks++;

        if (started) {
            for (int i = 0; i < columns.size(); i++) {
                Rectangle column = columns.get(i);
                column.x -= speed;
                // place the dead bird moving code here
               if (gameOver) {
                    bird.x -= 1;
                }
            }

            if (ticks % 2 == 0 && yMotion <15) { 
                yMotion += 2;   // controls the dropping of the bird
                                
            }

            for (int i = 0; i < columns.size(); i++) {
                Rectangle column = columns.get(i);

                if (column.x + column.width < 0) {
                    columns.remove(column);

                    if (column.y == 0) {
                        addColumn(false);
                    }
               }
            }

            bird.y += yMotion; //so bird keeps moving will stay still otherwise

            for (Rectangle column : columns) {
               
                if (column.y == 0 && bird.x + bird.width / 2 > column.x + column.width / 2 - 10 
                        && bird.x + bird.width / 2 < column.x + column.width / 2 + 10) {
                    score++;
                }

                if (column.intersects(bird)) {
                    gameOver = true;

                    if (bird.x <= column.x) { 
                        bird.x = column.x - bird.width;  //so the bird doesnt pass through the column
                        
                    } else {
                        if (column.y != 0) {
                            bird.y = column.y - bird.height;  //doesnt go inside the upper column
                        } else if (bird.y < column.height) {
                            bird.y = column.height;     //stays on top of column doesnt get inside
                        }
                    }
                }
            }

            if (bird.y > HEIGHT || bird.y < 0) {  //touches the top 
                gameOver = true;
            }

            if (bird.y + yMotion >= HEIGHT) {
                bird.y = HEIGHT - bird.height;
                gameOver = true;
            }
        }

        renderer.repaint();
    }

    public void repaint(Graphics g) {
        g.drawImage(bgImage, 0, 0, null);
        
        g.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height, null);

        for (Rectangle column : columns) {
            paintColumn(g, column);
        }

        g.setColor(Color.white);
        g.setFont(new Font("Arial", 1, 100));

        if (!started) {
            g.drawString("Click to start!", 75, HEIGHT / 2 - 50);
        }

        if (gameOver) {
            g.drawString("Game Over!", 100, HEIGHT / 2 - 50);
        }

        if (!gameOver && started) {
            g.drawString(String.valueOf(score), WIDTH / 2 - 25, 100);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        jump();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            jump();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

}
